export default function Contact() {
  return (
    <section id="contact" className="p-8 bg-accent/20 text-center">
      <h3 className="text-2xl font-bold text-primary mb-4">ติดต่อเรา</h3>
      <p className="mb-2">📞 081-234-5678 (คุณเอก - เจ้าของร้าน)</p>
      <p className="mb-6">🏠 123/45 ถนนบางนา กรุงเทพฯ</p>

      <div className="flex justify-center">
        <iframe
          title="map"
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!..." 
          width="100%"
          height="300"
          style={{ border: 0, borderRadius: "12px" }}
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </div>
    </section>
  );
}
