export default function Navbar() {
  return (
    <nav className="bg-primary text-white p-4 flex justify-between items-center shadow-md">
      <h1 className="text-xl font-bold text-accent">NK_Battery</h1>
      <ul className="flex gap-6">
        <li><a href="#gallery" className="hover:text-accent">ผลงาน</a></li>
        <li><a href="#contact" className="hover:text-accent">ติดต่อ</a></li>
      </ul>
    </nav>
  );
}
