export default function Gallery() {
  const images = ["/images/car1.jpg", "/images/car2.jpg", "/images/car3.jpg"];

  return (
    <section id="gallery" className="p-8 text-center">
      <h3 className="text-2xl font-bold text-primary mb-6">ผลงานของเรา</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {images.map((img, i) => (
          <img key={i} src={img} alt={`งาน ${i}`} className="rounded-xl shadow-lg" />
        ))}
      </div>
    </section>
  );
}
