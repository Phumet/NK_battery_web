export default function Hero() {
  return (
    <section className="text-center p-12 bg-gradient-to-r from-primary to-accent text-white">
      <h2 className="text-4xl md:text-6xl font-bold mb-4">บริการเปลี่ยนแบตเตอรี่รถยนต์</h2>
      <p className="text-lg md:text-xl">รวดเร็ว ราคาย่อมเยา ถึงที่ทั่วเมือง!</p>
    </section>
  );
}
