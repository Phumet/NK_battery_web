export default function Footer() {
  return (
    <footer className="bg-primary text-white text-center p-4 mt-6">
      <p>© 2025 NK_Battery - บริการเปลี่ยนแบตเตอรี่รถยนต์</p>
    </footer>
  );
}
